from flask import Flask, render_template
import os

app = Flask(__name__, static_folder='static', template_folder='templates')

@app.route('/')
def home():
    ascii_path = os.path.join(app.static_folder, 'ascii.txt')
    ascii_art = ''
    if os.path.exists(ascii_path):
        with open(ascii_path, 'r', encoding='utf-8') as f:
            ascii_art = f.read()
    return render_template('index.html', ascii_art=ascii_art)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
