const express = require('express');
const fetch = require('node-fetch');
const app = express();

app.get('/', async (req, res) => {
  try {
    const response = await fetch('http://flask:5000/');
    const flaskHtml = await response.text();

    res.send(`
      <h1>Hola desde el contenedor Node.js</h1>
      <p>Este servicio se comunica con Flask (Python)</p>
      <div style="border:1px solid #ccc;padding:10px;margin-top:15px;">
        <h3>Respuesta de Flask:</h3>
        ${flaskHtml}
      </div>
    `);
  } catch (error) {
    res.send(`<p>Error al conectar con Flask: ${error.message}</p>`);
  }
});

app.listen(3000, () => {
  console.log('Servidor Node.js corriendo en el puerto 3000');
});
