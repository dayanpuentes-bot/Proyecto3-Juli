// server.js
const express = require("express");
const app = express();
const port = 3000;

// Middleware para permitir JSON
app.use(express.json());

// Ruta principal
app.get("/", (req, res) => {
  res.send(`
    <html>
      <head>
        <title>Resultados del modelo</title>
      </head>
      <body style="font-family: sans-serif; text-align: center; margin-top: 50px;">
        <h1>Visualización desde Node.js</h1>
        <p>El servicio Flask está corriendo en el puerto 5000.</p>
        <p>Gráfico generado del modelo climático:</p>
        <img src="http://localhost:5000/static/grafico.png" alt="Gráfico del modelo" style="max-width: 600px;">
      </body>
    </html>
  `);
});

// Iniciar servidor
app.listen(port, "0.0.0.0", () => {
  console.log(`✅ Node app listening at http://0.0.0.0:${port}`);
});

